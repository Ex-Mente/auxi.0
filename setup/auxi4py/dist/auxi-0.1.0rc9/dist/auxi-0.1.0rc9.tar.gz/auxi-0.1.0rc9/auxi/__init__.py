"""auxi for Python Package

The purpose of this package is to make auxi's modeling and simulation framework
available through a series of Python modules for easy access and use.

Python version:  3.4.0
auxi version: 0.1.0"""

__version__ = "0.1.0"
