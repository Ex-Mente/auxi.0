"""auxi.modelling Package

The purpose of this package is to provide common classes and functions for the rest of the auxi.modelling namespace"""

__version__ = "0.1.0"

import auxi.core