"""auxi.modelling.accounting.financial Package

The purpose of this package is to provide common classes and functions for the rest of the auxi.modelling.accounting.financial namespace

This package contains two sub packages. calcualtion_engines and des (double entry system)."""

__version__ = "0.1.0"
